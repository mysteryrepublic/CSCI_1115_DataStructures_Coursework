
public interface TicTacToeConstants {
	public static int Player1 = 1; //Indicate player 1
	public static int Player2 = 2; //indicate player 2
	public static int Player1_Won = 1;//indicate player 1 won
	public static int Player2_won = 2;//indicate player 2 won
	public static int Draw = 3; //indicate draw
	public static int Continue = 4; //indicate continue

}
