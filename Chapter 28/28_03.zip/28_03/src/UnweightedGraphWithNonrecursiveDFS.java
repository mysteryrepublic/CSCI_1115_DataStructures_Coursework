/*
 *Shannon Vogelesang
 *05-21-2019
 *Description: Make it nonrecursive
 * 
 * */
import java.util.*;

public class UnweightedGraphWithNonrecursiveDFS<V> extends UnweightedGraph<V> {
	/** Construct an empty graph */
	public UnweightedGraphWithNonrecursiveDFS() {
	}

	/** Construct a graph from vertices and edges stored in arrays */
	public UnweightedGraphWithNonrecursiveDFS(V[] vertices, int[][] edges) {
		super(vertices, edges);
	}

	/** Construct a graph from vertices and edges stored in List */
	public UnweightedGraphWithNonrecursiveDFS(List<V> vertices, List<Edge> edges) {
		super(vertices, edges);
	}

	/** Construct a graph for integer vertices 0, 1, 2 and edge list */
	public UnweightedGraphWithNonrecursiveDFS(List<Edge> edges, int numberOfVertices) {
		super(edges, numberOfVertices);
	}

	/** Construct a graph from integer vertices 0, 1, and edge array */
	public UnweightedGraphWithNonrecursiveDFS(int[][] edges, int numberOfVertices) {
		super(edges, numberOfVertices);
	}
	/*
	 * Input: G = (V, E) and a starting vertex v
	 * Output: A DFS tree rooted at v
	 * 
	 * Tree dfs(v) {
	 *   push v to the stack;
	 *   mark x visited;
	 *   while (the stack is not empty) {
	 *     peek a vertex from the stack, say x;
	 *     if (x still has an unvisited neighbor, say y) {
	 *       parent[y] = x;
	 *       push y into the stack;
	 *       mark y visited;
	 *     }
	 *     else {  
	 *       pop a vertex from the stack;
	 *     }
	 *   }
	 * }  
	 */
	@Override /** Obtain a DFS tree starting from vertex v */
	public SearchTree dfs(int v) {
		LinkedList<Integer> stack = new LinkedList<>();
		List<Integer> searchOrder = new ArrayList<>();
		int[] parent = new int[vertices.size()];
		for(int i = 0; i < parent.length; i++) {
			parent[i] = -1;
		}
		boolean[] isVisited = new boolean[vertices.size()];
		stack.push(v);					//push v to the stack
		isVisited[v] = true;
		searchOrder.add(v);
		while(!stack.isEmpty()) {		//while the stack is not empty
			int x = stack.peek();		//peek a vertex from the stack
			int index = unvisitedNeighbor(neighbors.get(x), isVisited); 
			if(index != -1) {			
				Edge e = neighbors.get(x).get(index);
				stack.push(e.v);			
				searchOrder.add(e.v);
				parent[e.v] = x;			
				isVisited[e.v] = true;
			}
			else {
				stack.pop();
			}
		}
		return new SearchTree(v, parent, searchOrder);
	}
	private int unvisitedNeighbor(List<Edge> neighborEdges, boolean[] isVisited) {
		for(Edge e : neighborEdges) {
			if(!isVisited[e.v]) {
				return neighborEdges.indexOf(e);
			}
		}
		return -1;
	}
}

